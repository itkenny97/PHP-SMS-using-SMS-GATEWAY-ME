
<?php
require_once('smsGatewayV4.php');
session_start();

if (isset($_POST['send'])){
	$token = ""; //Your SMS GATEWAY ME API TOKEN

	$phone_number = $_POST['cpnumber'];
	$message = $_POST['txtmessage'];
	$deviceID = ; //Your SMS GATEWAY ME DEVICE ID
	$options = [];

	$smsGateway = new SmsGateway($token);
	$result = $smsGateway->sendMessageToNumber($phone_number, $message, $deviceID, $options);

	$_SESSION['sent'] = "Message Sent";
	header("Location: index.php");
}


?>
