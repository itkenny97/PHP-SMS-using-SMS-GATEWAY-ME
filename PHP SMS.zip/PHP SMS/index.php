<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="bootstrap4/css/bootstrap.min.css">
	<title></title>
</head>
<body>

<div class="container">
	<div class="row">
		<div class="col-md-5 mx-auto mt-5 p-5 bg-dark text-white rounded">
			<?php
			if(isset($_SESSION['sent'])){
				echo "<div class='alert alert-success text-center'>".$_SESSION['sent']."</div>";
			}
			?>
			<form action="sendSms.php" method="POST">
			<h1>Send Text Message</h1>
			<label>Contact Number</label>
			<input type="number" class="form-control" name="cpnumber" placeholder="Contact Number" required>
			<label>Message</label>
			<textarea class="form-control" name="txtmessage" placeholder="Enter your message here" required></textarea>
			<button class="btn btn-block btn-primary mt-4" name="send">Send</button>
			</form>
		</div>
	</div>
</div>

<script type="text/javascript" src="js/jquery/jquery-3.3.1.min.js"></script>
<script type="text/javascript" src="css/bootstrap4/js/bootstrap.min.js"></script>
</body>
</html>